// Escreva um script que determine se um número é primo.

const numero = prompt("Digite um número:");

function isPrimo(num) {
  if (num <= 1) {
    return false;
  }

  for (let i = 2; i <= Math.sqrt(num); i++) {
    if (num % i === 0) {
      return false;
    }
  }

  return true;
}

if (isPrimo(numero)) {
  alert("O número é primo.");
} else {
  alert("O número não é primo.");
}

