//(while) Escreva um programa que imprima na tela os números ímpares de 1 a 20.

let numero = 1;

while (numero <= 20) {
    if (numero % 2 !== 0) {
        document.write( numero + "<br>");
    }
    numero++;
}




