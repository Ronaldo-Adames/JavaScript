//Crie um programa que exiba uma contagem regressiva de 10 a 1. 
//Utilize um laço de repetição para iterar de 10 a 1 e exiba cada número.

let resultado = "";

for (let i = 10; i >= 1; i--) {
    resultado += i + " ";
}

alert("A contagem regressiva de 10 a 1 é: " + resultado);
