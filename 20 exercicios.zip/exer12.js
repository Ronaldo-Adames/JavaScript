//(for) Faça um programa que calcule a média de um vetor de números reais com 10 elemento.

const vetor = [2.5, 4.8, 6.3, 7.1, 3.9, 5.6, 9.2, 8.4, 1.7, 6.5];
let soma = 0;

for (let i = 0; i < vetor.length; i++) {
  soma += vetor[i];
}

const media = soma / vetor.length;

document.write("A média do vetor é: " + media);


