// Crie um script que com um número verifique se é par ou ímpar e exiba
// uma mensagem informando se o número é par ou ímpar.

/* const numero = prompt("Digite um número: ");

if (numero % 2 === 0) {
  alert("O número é par.");
} else {
  alert("O número é ímpar.");
}
 */

// ou 


// verificando se é número.

const numero = parseFloat(prompt("Digite um número:"));

if (isNaN(numero)) {
  alert("Valor inválido. Digite um número válido.");
} else if (numero % 2 === 0) {
  alert("O número é par.");
} else {
  alert("O número é ímpar.");
}
