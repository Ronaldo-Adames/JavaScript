//(do-while) Escreva um programa que solicite ao usuário para digitar uma senha, 
//repetindo a solicitação até que ele acerte a senha correta.


// Senha correta
var senhaCorreta = "senha123";

// Solicita ao usuário que digite a senha
var senhaDigitada;
do {
  senhaDigitada = prompt("Digite a senha (ou digite 'sair' para encerrar):");

  // Verifica se a senha digitada está correta
  if (senhaDigitada === senhaCorreta) {
    console.log("Senha correta! Acesso concedido.");
    break;
  } else if (senhaDigitada === "sair") {
    console.log("Programa encerrado pelo usuário.");
    break;
  } else {
    console.log("Senha incorreta. Tente novamente.");
  }
} while (true);
