//(for) Escreva um programa que gere a sequência de Fibonacci até o décimo termo.

// Função para gerar a sequência de Fibonacci até o décimo termo
function fibonacci() {
    var fibonacciSeq = [0, 1]; // Primeiros dois termos da sequência
  
    // Gera os próximos termos da sequência até o décimo termo
    for (var i = 2; i < 10; i++) {
      var nextTerm = fibonacciSeq[i - 1] + fibonacciSeq[i - 2];
      fibonacciSeq.push(nextTerm);
    }
  
    return fibonacciSeq;
  }
  
  // Chama a função para obter a sequência de Fibonacci
  var sequence = fibonacci();
  
  // Exibe os valores na tela usando Math.abs()
  for (var i = 0; i < sequence.length; i++) {
    document.write( " Termo " + (i + 1) + " : " + Math.abs(sequence[i]));
  }
  