//Crie um script que com a idade de uma pessoa em anos e converta para dias e exiba o resultado.

const idadeAnos = prompt("Digite a idade em anos: ");

const dias = idadeAnos * 365;

alert("A idade em dias é de: " + dias);

