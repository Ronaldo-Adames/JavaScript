//Crie um programa que solicite ao usuário uma frase e converta todas as letras para maiúsculas. 
//Utilize um laço de repetição para percorrer cada letra da
//frase e atribua o resultado a uma nova variável.

const frase = prompt("Digite uma frase:");
let fraseConvertida = "";

for (let i = 0; i < frase.length; i++) {
  const letraMaiuscula = frase[i].toUpperCase();
  fraseConvertida += letraMaiuscula;
}

alert("Frase convertida para maiúsculas: " + fraseConvertida);
