// Crie um script que com o preço de um produto calcule o valor com desconto de 10% 
//e exiba o valor com desconto.

const preco = prompt("Digite o preço: ");

const desconto = preco * 0.1;

const precoComDesconto = preco - desconto;

alert("O valor com desconto é de: " +precoComDesconto);

