//(for-each) Crie um programa que conte a quantidade de letras "a" em uma string 
//informada pelo usuário.

// Solicita ao usuário que digite uma string
var string = prompt("Digite uma string:");

// Converte a string para letras minúsculas (opcional)
string = string.toLowerCase();

// Variável para armazenar a quantidade de letras "a"
var contador = 0;

// Percorre cada caractere da string utilizando forEach
Array.from(string).forEach(function(caractere) {
  if (caractere === "a") {
    contador++;
  }
});

// Exibe a quantidade de letras "a" na string
alert("A quantidade de letras 'a' na string é: " + contador);
