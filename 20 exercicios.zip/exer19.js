//(for) Faça um programa que imprima na tela os números primos de 1 a 100.

// Função para verificar se um número é primo
function isPrimo(numero) {
  if (numero <= 1) {
    return false;
  }

  for (var i = 2; i <= Math.sqrt(numero); i++) {
    if (numero % i === 0) {
      return false;
    }
  }

  return true;
}

// Variável para armazenar os números primos
var primos = [];

// Encontra os números primos de 1 a 100
for (var i = 1; i <= 100; i++) {
  if (isPrimo(i)) {
    primos.push(i);
  }
}

// Exibe os números primos em uma caixa de diálogo
alert("Números primos de 1 a 100:\n" + primos.join(", "));
