//Crie um programa que solicite uma palavra ao usuário e verifique se contém uma letra específica. 
//Utilize um laço de repetição para percorrer cada letra da
//palavra e um condicional para verificar se a letra desejada está presente.

const palavra = prompt("Digite uma palavra:");
const letra = prompt("Digite a letra que deseja verificar:");

let encontrada = false;

for (let i = 0; i < palavra.length; i++) {
  if (palavra[i] === letra) {
    encontrada = true;
    break;
  }
}

if (encontrada) {
  alert(`A palavra "${palavra}" contém a letra "${letra}".`);
} else {
  alert(`A palavra "${palavra}" não contém a letra "${letra}".`);
}


// ou

/*
const frase = prompt("frase");

frase 'abcd'

frase.search("a")
0
frase.search("b")
1
frase.search("2")
2

if (frase.search("a")) {
    alert("tem A");
} else 
alert 
}
}

*/
