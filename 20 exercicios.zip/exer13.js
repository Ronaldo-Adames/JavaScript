//(do-while) Crie um jogo de adivinhação em que o usuário tem que tentar acertar um número aleatório
// de 1 a 100, dando dicas de "maior" ou "menor" até acertar.

const numeroAleatorio = Math.floor(Math.random() * 100) + 1;
let tentativas = 0;
let palpite;

do {
  palpite = parseInt(prompt("Tente adivinhar o número (entre 1 e 100):"));
  tentativas++;

  if (palpite < numeroAleatorio) {
    alert("O número é maior!");
  } else if (palpite > numeroAleatorio) {
    alert("O número é menor!");
  }
} while (palpite !== numeroAleatorio);

alert(`Parabéns! Você acertou o número ${numeroAleatorio} em ${tentativas} tentativa(s)!`);
