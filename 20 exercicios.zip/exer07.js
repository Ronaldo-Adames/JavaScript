//Crie um programa que solicite ao usuário três notas e calcule a média. 
//Se alguma nota for inválida (for menor que 0 ou maior que 10), solicite novamente essa nota.
//Utilize um laço de repetição e condicional para validar as notas.

let nota1 = parseFloat(prompt("Digite a primeira nota: "));
let nota2 = parseFloat(prompt("Digite a segunda nota: "));
let nota3 = parseFloat(prompt("Digite a terceira nota: "));

while (nota1 < 0 || nota1 > 10 || isNaN(nota1)) {
  nota1 = parseFloat(prompt("Nota inválida. Digite novamente a primeira nota: "));
}

while (nota2 < 0 || nota2 > 10 || isNaN(nota2)) {
  nota2 = parseFloat(prompt("Nota inválida. Digite novamente a segunda nota: "));
}

while (nota3 < 0 || nota3 > 10 || isNaN(nota3)) {
  nota3 = parseFloat(prompt("Nota inválida. Digite novamente a terceira nota: "));
}

const media = (nota1 + nota2 + nota3) / 3;

alert(`A média das notas é: ${media.toFixed(2)}`);
