//Crie um script que solicite um número de telefone ao usuário 
//e formate-o no formato "(XX) XXXX-XXXX" e exiba o número de telefone formatado.

const numeroTelefone = prompt("Digite um número de telefone: ");

const numerosApenas = numeroTelefone.replace(/\D/g, "");

const numeroFormatado = `(${numerosApenas.slice(0, 2)}) ${numerosApenas.slice(2, 6)}-${numerosApenas.slice(6, 10)}`;

alert("Número de telefone formatado: " + numeroFormatado)


