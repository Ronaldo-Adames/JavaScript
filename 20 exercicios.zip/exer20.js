// (while) Escreva um programa que calcule a soma dos números pares de 1 a 50.



var soma = 0;

var numero = 1;

while (numero <= 50) {
  if (numero % 2 === 0) {
    soma += numero;
  }
  numero++;
}

document.write("A soma dos números pares de 1 a 50 é: " + soma);
