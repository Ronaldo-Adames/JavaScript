//Crie um programa que exiba todos os números pares de 1 a 10. 
//Utilize um laço de repetição e condicional para verificar se cada número é par.

let resultado = "";

for (let i = 1; i <= 10; i++) {
  if (i % 2 === 0) {
    resultado += i + " ";
  }
}

alert("Números pares de 1 a 10: " + resultado);
