//(for-each) Crie um programa que some todos os valores de um vetor de inteiros com 100 elementos.

// Vetor de inteiros com 100 elementos
var vetor = [];

// Função para gerar os números de 1 a 100
function gerarNumeros() {
  for (var i = 1; i <= 100; i++) {
    vetor.push(i);
  }
}

// Chama a função para gerar os números
gerarNumeros();

// Variável para armazenar a soma
var soma = 0;

// Percorre cada elemento do vetor e soma ao total
vetor.forEach(function(elemento) {
  soma += elemento;
});

// Exibe o resultado da soma na tela
document.write("A soma dos elementos é: " + soma);


