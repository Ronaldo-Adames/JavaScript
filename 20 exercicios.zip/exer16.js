//(while) Faça um programa que leia uma lista de números inteiros até 
//o usuário digitar zero e exiba o maior número digitado.

let maior = 0;

let numero;
do {
  numero = parseInt(prompt("Digite um número inteiro (digite 0 para sair):"));

  if (numero > maior) {
    maior = numero;
  }
} while (numero !== 0);


document.write("O maior número digitado foi: " + maior);
